#include "error.h"
#include "csapp.h"

#include <assert.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdarg.h>

static const char *err_msgs[] = {
    "Parse success, no error\n",
    "Request not initialized\n",
    "Response not initalized\n",
    "Http method is not supported\n",
    "Http version is not supported\n",
    "Missing host name\n",
    "Request is not completed\n",
    "Response is not completed\n",
    "Protocol is not supported\n",
    "Invalid host name\n",
    "Invalid port number\n",
    "Failed to parse url\n",
    "Too many headers\n",
    "Http request body not supported\n",
    "Buffer size is not enough\n",
    "Malloc fails\n",
    "Failed to parse status code of http response\n",
    "Invalid parameter\n",
    "Unknown error, use errno\n",
    "getnameinfo fails\n",
    "Open-clientfd fails\n",
    "Cache item not found\n",
    "No write privilege, call pthread_rwlock_wrlock() first\n",
    "Cache object size exceeds the max object size\n",
    "Cache is empty\n",
};

const char *my_error_msg(my_err_t err_code)
{
    static_assert(sizeof(err_msgs) / sizeof(char *) == MY_ERR_SIZE_IDENTITY, "MY_ERR_SIZE_IDENTITY is not equal to err_msg.length");
    assert(err_code >= 0 && err_code < MY_ERR_SIZE_IDENTITY);

    return err_msgs[err_code];
}

static sem_t print_mutex;

static void init_sem()
{
    Sem_init(&print_mutex, 0, 1);
}

void my_error(const char *msg, ...)
{
    static pthread_once_t once = PTHREAD_ONCE_INIT;
    pthread_once(&once, init_sem);

    P(&print_mutex);
    va_list vargs;
    va_start(vargs, msg);

    vprintf(msg, vargs);

    va_end(vargs);
    V(&print_mutex);
}

void __ig__no__re_er__ror(const char *msg, ...)
{
    return;
}