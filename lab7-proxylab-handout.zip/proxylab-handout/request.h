#pragma once

#ifndef REQUEST_PROC_HEAD
#define REQUEST_PROC_HEAD

const int HEADER_MAX_SIZE;
const int BUF_MAXSIZE;

typedef enum Version
{
    VER_SION_BEGIN,
    V10,
    V11,
    V20,
    VER_SION_END,
} version_t;

typedef struct Header
{
    char *key;
    char *val;
} header_t;

#define BUF_MAXSIZE 256
#define HEADER_MAX_SIZE 100

typedef struct HttpHeader
{
    char *host;
    char *path;
    char *body;
    char *status_code;
    char *status_info;
    char *port_number;
    char *query;
    char method[BUF_MAXSIZE];

    version_t version;

    header_t headers[HEADER_MAX_SIZE];
    int header_size;
} request_t, response_t;

#undef BUF_MAXSIZE
#undef HEADER_MAX_SIZE

enum MyError;
typedef enum MyError my_err_t;

void init_request(request_t *request);
void clear_request(request_t *request);
void init_response(response_t *response);
void clear_response(response_t *response);

const char *get_header(request_t *request, const char *key);
int set_header(request_t *request, const char *key, const char *val, int val_len);

void remove_header(request_t *request, const char *key);
my_err_t append_header(request_t *reqeust, const char *key, int key_len, const char *val, int val_len);

my_err_t request_debug_str(char *buf, int buf_len, const request_t *request);

#endif // REQEUST_PROC_HEADER