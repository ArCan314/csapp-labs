#include "error_response.h"

const char *response_400(void)
{
    return "HTTP/1.0 400 Bad Request\r\n"
           "Content-Type: text/html\r\n"
           "Connection: close\r\n"
           "Server: CSAPP-HTTP-PROXY/SEQUENTIAL\r\n"
           "\r\n"
           "<html><title>Error</title>"
           "<body>400 Bad Request</body></html>\r\n";
}

const char *response_404(void)
{
    return "HTTP/1.0 404 Not Found\r\n"
           "Content-Type: text/html\r\n"
           "Connection: close\r\n"
           "Server: CSAPP-HTTP-PROXY/SEQUENTIAL\r\n"
           "\r\n"
           "<html><title>Error</title>"
           "<body>404 Not Found</body></html>\r\n";
}

const char *response_405(void)
{
    return "HTTP/1.0 405 Method Not Allowed\r\n"
           "Content-Type: text/html\r\n"
           "Connection: close\r\n"
           "Server: CSAPP-HTTP-PROXY/SEQUENTIAL\r\n"
           "Allow: GET\r\n"
           "\r\n"
           "<html><title>Error</title>"
           "<body>405 Method Not Allowed</body></html>\r\n";
}

const char *response_431(void)
{
    return "HTTP/1.0 431 Request Header Fields Too Large\r\n"
           "Content-Type: text/html\r\n"
           "Connection: close\r\n"
           "Server: CSAPP-HTTP-PROXY/SEQUENTIAL\r\n"
           "\r\n"
           "<html><title>Error</title>"
           "<body>431 Request Header Fields Too Large</body></html>\r\n";
}

const char *response_500(void)
{
    return "HTTP/1.0 500 Internal Server Error\r\n"
           "Content-Type: text/html\r\n"
           "Connection: close\r\n"
           "Server: CSAPP-HTTP-PROXY/SEQUENTIAL\r\n"
           "\r\n"
           "<html><title>Error</title>"
           "<body>500 Internal Server Error</body></html>\r\n";
}