#pragma once

const char *response_400(void);
const char *response_404(void);
const char *response_405(void);
const char *response_431(void);
const char *response_500(void);
