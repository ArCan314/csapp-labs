#include "parse.h"
#include "error.h"
#include "request.h"

#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

typedef struct HttpHeader http_t;

static int is_in_set(const char *target, const char *set[], int set_size);
static int is_zero_inited(http_t *http_hdr);
static void clear_flag(int *flag, int pos);
static int ignore_spaces(const char *http_content, int pos);
static int ignore_crlf(const char *http_content, int pos);
static int is_query_begin(const char c);
static int is_url_char(const char c);
static my_err_t parse_url(const char *http_content, int *start, http_t *http_hdr);
static my_err_t parse_http_header(const char *http_content, int *start, http_t *http_hdr);
static my_err_t parse_version(const char *http_content, int *start, http_t *http_hdr);
static my_err_t parse_method(const char *http_content, int *start, http_t *http_hdr);
static my_err_t parse_status_code(const char *http_content, int *start, http_t *response);

my_err_t parse_request_header(const char *http_request, request_t *request)
{
    if (!is_zero_inited(request))
        return REQUEST_NOT_INITED;

    int l = 0, r = 0;
    int state = 0;

    static const int METHOD_PARSED = 0x1;
    static const int URL_PARSED = 0x2;
    static const int VERSION_PARSED = 0x4;
    static const int HOST_PARSED = 0x8;
    static const int HEADER_PARSED = 0x10;
    int flag = 0x1f;

    while (http_request[r])
    {
        switch (state)
        {
        case 0: // parse method, isalpha->0 space->1 else-> fault
        {
            my_err_t err;
            if ((err = parse_method(http_request, &r, request)) == NO_ERROR)
            {
                l = r = ignore_spaces(http_request, r);
                clear_flag(&flag, METHOD_PARSED);
                state = 1;
            }
            else
                return err;
            break;
        }
        case 1: // parse URL
        {
            my_err_t err;
            if ((err = parse_url(http_request, &r, request)) != NO_ERROR)
            {
                return err;
            }
            else
            {
                l = r = ignore_spaces(http_request, r);
                clear_flag(&flag, URL_PARSED);
                state = 2;
            }
            break;
        }

        case 2: // parse version, ok->3, else->fault
        {
            my_err_t err;
            if ((err = parse_version(http_request, &r, request)) == NO_ERROR)
            {
                l = r = ignore_spaces(http_request, r);
                clear_flag(&flag, VERSION_PARSED);
                state = 3;
            }
            else
                return err;
            break;
        }
        case 3: // parse header
        {
            my_err_t err;
            if (http_request[r] != '\r')
            {
                err = parse_http_header(http_request, &r, request);

                if (err != NO_ERROR)
                    return err;

                l = r = ignore_crlf(http_request, r);
            }
            else
            {
                clear_flag(&flag, HEADER_PARSED);
                state = 4;
            }
            break;
        }
        case 4: // check if host is set
        {
            const char *val;
            if (request->host)
            {
                clear_flag(&flag, HOST_PARSED);
                l = r = ignore_spaces(http_request, r);
                state = 5;
            }
            else if ((val = get_header(request, "host")))
            {
                const char *div = strchr(val, ':');
                if (div)
                {
                    int port_number_len = strlen(div + 1);

                    request->port_number = (char *)malloc(port_number_len + 1);
                    if (!request->port_number)
                        return MALLOC_FAIL;
                    strcpy(request->port_number, div + 1);

                    request->host = (char *)malloc(div - val + 1);
                    if (!request->host)
                        return MALLOC_FAIL;
                    request->host[div - val] = '\0';
                    memcpy(request->host, val, div - val);
                }
                else
                {
                    request->host = (char *)malloc(strlen(val) + 1);
                    if (!request->host)
                        return MALLOC_FAIL;

                    strcpy(request->host, val);
                }

                clear_flag(&flag, HOST_PARSED);
                l = r = ignore_spaces(http_request, r);
                state = 5;
            }
            else
                return HOST_MISSING;
            break;
        }
        case 5:
            assert(0); // shouldn't parse body in http request header
            return BODY_NOT_SUPPORTED;
            break;
        default:
            // unexpected state
            assert(0);
            break;
        }
    }

    if (flag)
        return INCOMPLETE_REQUEST;

    return NO_ERROR;
}

my_err_t parse_response_header(const char *http_content, response_t *response)
{
    if (!is_zero_inited(response))
        return RESPONSE_NOT_INITED;

    int l = 0, r = 0;
    int state = 0;

    static const int VERSION_PARSED = 0x1;
    static const int STATUS_CODE_PARSED = 0x2;
    static const int STATUS_INFO_PARSED = 0x4;
    static const int HEADER_PARSED = 0x8;
    int flag = 0xf;

    while (http_content[r])
    {
        switch (state)
        {
        case 0: // parse version
        {
            my_err_t err;
            if ((err = parse_version(http_content, &r, response) == NO_ERROR))
            {
                l = r = ignore_spaces(http_content, r);
                clear_flag(&flag, VERSION_PARSED);
                state = 1;
            }
            else
                return err;
            break;
        }
        case 1: // parse status code
        {
            my_err_t err;
            if ((err = parse_status_code(http_content, &r, response)) != NO_ERROR)
            {
                return err;
            }
            else
            {
                l = r = ignore_spaces(http_content, r);
                clear_flag(&flag, STATUS_CODE_PARSED);
                state = 2;
            }
            break;
        }
        case 2: // parse status info
        {
            if (http_content[r] != '\r')
                r++;
            else
            {
                response->status_info = (char *)malloc(r - l + 1);
                if (!response->status_info)
                    return MALLOC_FAIL;

                response->status_info[r - l] = '\0';
                memcpy(response->status_info, &http_content[l], r - l);

                l = r = ignore_crlf(http_content, r);
                clear_flag(&flag, STATUS_INFO_PARSED);
                state = 3;
            }
            break;
            // my_err_t err;
            // if ((err = parse_version(http_content, &r, &response)) == NO_ERROR)
            // {
            //     l = r = ignore_spaces(http_request, r);
            //     state = 3;
            // }
            // else
            //     return err;
            // break;
        }
        case 3: // parse header
        {
            my_err_t err;
            if (http_content[r] != '\r')
            {
                err = parse_http_header(http_content, &r, response);

                if (err != NO_ERROR)
                    return err;

                l = r = ignore_crlf(http_content, r);
            }
            else
            {
                l = r = ignore_crlf(http_content, r);
                clear_flag(&flag, HEADER_PARSED);
                state = 4;
            }
            break;
        }
        case 4:
            assert(0); // should be EOF
            return BODY_NOT_SUPPORTED;
            break;
        default:
            // unexpected state
            assert(0);
            break;
        }
    }

    if (flag)
        return INCOMPLETE_RESPONSE;

    return NO_ERROR;
}

static int is_in_set(const char *target, const char *set[], int set_size)
{
    for (int i = 0; i < set_size; i++)
    {
        if (!strncmp(target, set[i], strlen(set[i])))
            return 1;
    }
    return 0;
}

static int is_zero_inited(http_t *http_hdr)
{
    char *start = (char *)http_hdr;
    if (!start)
        return 0;

    for (int i = 0; i < sizeof(http_t); i++)
    {
        if (*start != 0)
            return 0;
    }
    return 1;
}

static void clear_flag(int *flag, int pos)
{
    *flag &= ~pos;
}

static int ignore_spaces(const char *http_content, int pos)
{
    while (http_content[pos] && isspace(http_content[pos]))
        pos++;
    return pos;
}

static int ignore_crlf(const char *http_content, int pos)
{
    if (http_content[pos] == '\r' && http_content[pos + 1] == '\n')
        pos += 2;
    else if (http_content[pos] == '\n')
        pos++;
    return pos;
}

static int is_query_begin(const char c)
{
    return (c == '?' || c == '#');
}

static int is_url_char(const char c)
{
    return (isalnum(c) || c == '-' || c == '/' || c == '.' || c == '_' || c == '~' || c == '%');
}

static my_err_t parse_url(const char *http_content, int *start, http_t *http_hdr)
{
    int l = *start, r = *start;
    if (http_content[r] == '/')
    {
        while (http_content[r] && !isspace(http_content[r]) && !is_query_begin(http_content[r]))
            r++;

        http_hdr->path = (char *)malloc(r - l + 1);
        if (!http_hdr->path)
            return MALLOC_FAIL;

        http_hdr->path[r - l] = '\0';
        memcpy(http_hdr->path, &http_content[l], r - l);

        if (is_query_begin(http_content[r]))
        {
            l = r;
            while (http_content[r] && !isspace(http_content[r]))
                r++;

            http_hdr->query = (char *)malloc(r - l + 1);
            if (!http_hdr->query)
                return MALLOC_FAIL;

            http_hdr->query[r - l] = '\0';
            memcpy(http_hdr->query, &http_content[l], r - l);
        }

        *start = r;
        return NO_ERROR;
    }
    else
    {
        // http(s)://host(:port)/path
        int state = 0, is_done = 0;

        while (http_content[r] && !is_done)
        {
            switch (state)
            {
            case 0:                                                           // match http(s)://
                if (!strncmp(&http_content[l], "http://", strlen("http://"))) // TODO: use constant
                {
                    l = r = r + strlen("http://");
                    state = 1;
                }
                else if (!strncmp(&http_content[l], "https://", strlen("https://")))
                {
                    l = r = r + strlen("https://");
                    state = 1;
                }
                else
                {
                    // return INVALID_PROTOCOL;
                    // skip protocol
                    state = 1;
                }
                break;
            case 1: // match host
                if (isalnum(http_content[r]) || http_content[r] == '.' || http_content[r] == '-')
                    r++;
                else if (http_content[r] == ':' || http_content[r] == '/')
                {
                    http_hdr->host = (char *)malloc(r - l + 1);
                    if (!http_hdr->host)
                        return MALLOC_FAIL;

                    http_hdr->host[r - l] = '\0';
                    memcpy(http_hdr->host, &http_content[l], r - l);

                    l = r;
                    state = http_content[r] == ':' ? 2 : 3;
                }
                else
                    return INVALID_HOST;

                break;
            case 2: // match port number
                if (http_content[r] == ':')
                    l = r = r + 1;
                else if (isdigit(http_content[r]))
                    r++;
                else if (http_content[r] == '/' || isspace(http_content[r]))
                {
                    http_hdr->port_number = (char *)malloc(r - l + 1);
                    if (!http_hdr->port_number)
                        return MALLOC_FAIL;

                    http_hdr->port_number[r - l] = '\0';
                    memcpy(http_hdr->port_number, &http_content[l], r - l);

                    if (isspace(http_content[r]))
                        is_done = 1;
                    else
                    {
                        l = r;
                        state = 3;
                    }
                }
                else
                {
                    return INVALID_PORT_NUMBER;
                }
                break;

            case 3: // match path
                if (is_url_char(http_content[r]))
                    r++;
                else if (http_content[r] == '#' || http_content[r] == '?' || isspace(http_content[r]))
                {
                    http_hdr->path = (char *)malloc(r - l + 1);
                    if (!http_hdr->path)
                        return MALLOC_FAIL;

                    http_hdr->path[r - l] = '\0';
                    memcpy(http_hdr->path, &http_content[l], r - l);

                    if (isspace(http_content[r]))
                        is_done = 1;
                    else
                    {
                        l = r;
                        state = 4;
                    }
                }
                break;
            case 4: // match query
                if (!isspace(http_content[r]))
                    r++;
                else
                {
                    http_hdr->query = (char *)malloc(r - l + 1);
                    if (!http_hdr->query)
                        return MALLOC_FAIL;

                    http_hdr->query[r - l] = '\0';
                    memcpy(http_hdr->query, &http_content[l], r - l);
                    is_done = 1;
                }
                break;
            default:
                // TODO error
                assert(0);
                break;
            }
        }
        *start = r;
        return is_done ? NO_ERROR : PARSE_URL_FAIL;
    }

    return PARSE_URL_FAIL;
}

static my_err_t parse_http_header(const char *http_content, int *start, http_t *http_hdr)
{
    int l = *start, r = *start;

    // TODO: use DFA

    const char *key, *val;
    int key_len = 0, val_len = 0;

    key = &http_content[l];
    while (http_content[r] != ':')
        r++;

    key_len = r - l;

    r++;
    l = r;

    if (http_content[r] == ' ')
        l = r = r + 1;

    val = &http_content[r];
    while (http_content[r] != '\r')
        r++;
    val_len = r - l;

    if (append_header(http_hdr, key, key_len, val, val_len) == -1)
        return TOO_MANY_HEADERS;

    *start = r;
    return NO_ERROR;
}

static my_err_t parse_version(const char *http_content, int *start, http_t *http_hdr)
{
    int l = *start, r = *start;

    if (!strncasecmp(&http_content[l], "http/1.0", strlen("http/x.x")))
        http_hdr->version = V10;
    else if (!strncasecmp(&http_content[l], "http/1.1", strlen("http/x.x")))
        http_hdr->version = V11;
    else if (!strncasecmp(&http_content[l], "http/2.0", strlen("http/x.x")))
        http_hdr->version = V20;
    else
        return UNSUPPORTED_VERSION;

    r += strlen("http/x.x");
    *start = r;

    return NO_ERROR;
}

static my_err_t parse_method(const char *http_content, int *start, request_t *request)
{
    static const char *SUPPORTED_METHODS[] = {"GET", "POST", "HEAD", "PUT", "DELETE", "CONNECT", "OPTIONS", "TRACE", "PATCH"};

    int l = *start, r = *start;
    while (isalpha(http_content[r]))
        r++;

    if (is_in_set(&http_content[l], SUPPORTED_METHODS, sizeof(SUPPORTED_METHODS) / sizeof(char *)))
    {
        strncpy(request->method, &http_content[l], r - l);
        request->method[r - l] = '\0';
    }
    else
        return UNSUPPORTED_METHOD;

    *start = r;
    return NO_ERROR;
}

static my_err_t parse_status_code(const char *http_content, int *start, http_t *response)
{
    int l = *start, r = *start;

    while (isdigit(http_content[r]))
        r++;

    if (isspace(http_content[r]))
    {
        response->status_code = (char *)malloc(r - l + 1);
        if (!response->status_code)
            return MALLOC_FAIL;
        response->status_code[r - l] = '\0';

        memcpy(response->status_code, &http_content[l], r - l);
    }
    else
        return PARSE_STATUS_CODE_FAIL;

    *start = r;
    return NO_ERROR;
}