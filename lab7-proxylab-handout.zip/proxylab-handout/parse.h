#pragma once

#ifndef PARSE_PROC_HEAD
#define PARSE_PROC_HEAD

struct HttpHeader;
typedef struct HttpHeader request_t, response_t;

enum MyError;
typedef enum MyError my_err_t;

my_err_t parse_request_header(const char *http_request, request_t *request);
my_err_t parse_response_header(const char *http_response, response_t *response);


#endif // PARSE_PROC_HEADER