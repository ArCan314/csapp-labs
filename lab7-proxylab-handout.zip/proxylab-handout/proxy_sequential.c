// A Sequential HTTP proxy

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "csapp.h"
#include "error.h"
#include "error_response.h"
#include "parse.h"
#include "request.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/* You won't lose style points for including this long line in your code */
static const char *USER_AGENT_HEADER = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

static const char *DEFAULT_PROXY_LISTEN_PORT = "12345";

static my_err_t accept_dbg(int listen_fd, int *client_fd);
static int min(int a, int b) { return (a < b) ? a : b; }
static int max(int a, int b) { return (a > b) ? a : b; }
static my_err_t handle_connection(int client_fd);
static my_err_t recv_hdr_from(int fd, char *buf, int buf_size, int *read_len, rio_t *rio_buf_p);
static my_err_t forward(int client_fd, const request_t *req);
static my_err_t print_http_debug(struct HttpHeader *hdr);

int main(const int argc, const char *argv[])
{
    char *fd = DEFAULT_PROXY_LISTEN_PORT;
    if (argc == 2)
        fd = argv[1];
    int listen_fd = Open_listenfd(fd);

    while (1)
    {
        my_info("listening...\n");

        int client_fd;
        my_err_t err = accept_dbg(listen_fd, &client_fd);
        if (err != NO_ERROR)
        {
            if (err == GETNAMEINFO_ERROR)
            {
                int res = rio_writen(client_fd, (void *)response_404(), strlen(response_404()));
                if (res < 0)
                    my_error("errno(%d): %s\n", errno, strerror(errno));
            }
            else
            {
                int res = rio_writen(client_fd, (void *)response_500(), strlen(response_500()));
                if (res < 0)
                    my_error("errno(%d): %s\n", errno, strerror(errno));
            }
        }
        else
        {
            err = handle_connection(client_fd);
            const char *err_response = NULL;

            switch (err)
            {
            case NO_ERROR:
                break;

            case UNSUPPORTED_METHOD:
                my_error(my_error_msg(err));
                err_response = response_405();
                break;

            case BUFFER_SIZE_TOO_SMALL:
                my_error(my_error_msg(err));
                err_response = response_431();
                break;

            case GETNAMEINFO_ERROR:
                err_response = response_404();
                break;

            case UNKNOWN_ERROR:
                my_error("errno(%d): %s\n", errno, strerror(errno));
                err_response = response_500();
                break;

            default:
                my_error(my_error_msg(err));
                err_response = response_500();
                break;
            }

            if (err_response)
            {
                int res = rio_writen(client_fd, (void *)err_response, strlen(err_response));
                if (res < 0)
                    my_error("errno(%d): %s\n", errno, strerror(errno));
            }
        }

        Close(client_fd);
        my_info("connection closed\n");
    }

    // printf("%s", USER_AGENT_HEADER);
    return 0;
}

static my_err_t accept_dbg(int listen_fd, int *client_fd)
{
    if (!client_fd)
        return INVALID_PARAM;

    struct sockaddr_storage info;
    socklen_t info_len = sizeof(info);

    memset(&info, 0, sizeof(info));

    *client_fd = Accept(listen_fd, (SA *)&info, &info_len);
    char host[256], serv[256];

    int res = getnameinfo((SA *)&info, sizeof(struct sockaddr_storage), host, sizeof(host), serv, sizeof(serv), 0);
    if (res != 0)
    {
        my_error("getnameinfo error: %s", gai_strerror(res));
        return GETNAMEINFO_ERROR;
    }

    my_info("Get connection from host %s with port %s, client_fd = %d\n", host, serv, *client_fd);

    return NO_ERROR;
}

static my_err_t recv_hdr_from(int fd, char *buf, int buf_size, int *read_len, rio_t *rio_buf_p)
{
    if (buf_size <= 0 || buf[0] != '\0')
        return INVALID_PARAM;

    int byte = 0, read_res = 0;
    char recv_buf[1000];

    rio_t rio_buf;
    if (!rio_buf_p)
    {
        Rio_readinitb(&rio_buf, fd);
        rio_buf_p = &rio_buf;
    }

    while ((read_res = rio_readlineb(rio_buf_p, recv_buf, min(sizeof(recv_buf), buf_size))) > 0)
    {
        byte += read_res;
        if (byte >= buf_size)
            return BUFFER_SIZE_TOO_SMALL;

        my_info("%s", recv_buf);
        strcat(buf, recv_buf);
        if (strnlen(recv_buf, sizeof(recv_buf)) == 2 && recv_buf[0] == '\r' && recv_buf[1] == '\n')
            break;
    }

    if (read_res == -1)
        return UNKNOWN_ERROR;

    if (read_len)
        *read_len = byte;
    return NO_ERROR;
}

static my_err_t print_http_debug(struct HttpHeader *hdr)
{
    char req_dbg[2000] = {'\0'};

    my_err_t err = request_debug_str(req_dbg, sizeof(req_dbg), hdr);
    if (err != NO_ERROR)
        return err;

    my_info("%s\n", req_dbg);
    return NO_ERROR;
}

static my_err_t forward(int client_fd, const request_t *req)
{
    char forward_content[1000] = {'\0'};
    char buf[1000] = {'\0'};
    my_err_t err;

    sprintf(buf, "%s %s%s HTTP/1.0\r\n", req->method, req->path, req->query ? req->query : "");
    strcat(forward_content, buf);

    for (int i = 0; i < req->header_size; i++)
    {
        if (!strcasecmp(req->headers[i].key, "Proxy-Connection") ||
            !strcasecmp(req->headers[i].key, "Cache-Control") ||
            !strcasecmp(req->headers[i].key, "Connection"))
            continue;
        sprintf(buf, "%s: %s\r\n", req->headers[i].key, req->headers[i].val);
        strcat(forward_content, buf);
    }

    sprintf(buf, "\r\n");
    strcat(forward_content, buf);

    int forward_fd = open_clientfd(req->host, req->port_number ? req->port_number : (char *)"80");
    if (forward_fd < 0)
        return OPENFD_FAIL;

    my_info("Open connection %s:%s\n", req->host, req->port_number ? req->port_number : "80");

    int res = rio_writen(forward_fd, forward_content, strlen(forward_content));
    if (res == -1)
    {
        int errno_save = errno;
        Close(forward_fd);
        errno = errno_save;
        return UNKNOWN_ERROR;
    }

    buf[0] = '\0';
    rio_t forward_rio;
    rio_readinitb(&forward_rio, forward_fd);
    err = recv_hdr_from(forward_fd, buf, sizeof(buf), NULL, &forward_rio);
    if (err != NO_ERROR)
    {
        int errno_save = errno;
        Close(forward_fd);
        errno = errno_save;
        return err;
    }

    response_t response_hdr;
    init_response(&response_hdr);

    err = parse_response_header(buf, &response_hdr);
    if (err != NO_ERROR)
    {
        int errno_save = errno;
        clear_response(&response_hdr);
        Close(forward_fd);
        errno = errno_save;
        return 0;
    }

    print_http_debug(&response_hdr);
    res = rio_writen(client_fd, buf, strlen(buf));
    if (res < 0)
    {
        int errno_save = errno;
        Close(forward_fd);
        clear_response(&response_hdr);
        errno = errno_save;
        return UNKNOWN_ERROR;
    }

    if (!get_header(&response_hdr, "content-length"))
    {
        clear_response(&response_hdr);
        while ((res = rio_readnb(&forward_rio, buf, sizeof(buf))) > 0)
        {
            res = rio_writen(client_fd, buf, res);
            if (res < 0)
            {
                int errno_save = errno;
                Close(forward_fd);
                errno = errno_save;
                return UNKNOWN_ERROR;
            }
        }

        if (res < 0)
        {
            int errno_save = errno;
            Close(forward_fd);
            errno = errno_save;
            return UNKNOWN_ERROR;
        }
    }
    else
    {
        const char *val = get_header(&response_hdr, "content-length");
        int len = atoi(val);

        clear_response(&response_hdr);
        int byte = 0;

        while (len > 0 && (byte = rio_readnb(&forward_rio, buf, min(sizeof(buf), len))) > 0)
        {
            len -= byte;
            res = rio_writen(client_fd, buf, byte);
            if (res < 0)
            {
                int errno_save = errno;
                Close(forward_fd);
                errno = errno_save;
                return UNKNOWN_ERROR;
            }
        }

        if (byte < 0)
        {
            int errno_save = errno;
            Close(forward_fd);
            errno = errno_save;
            return UNKNOWN_ERROR;
        }
    }
    Close(forward_fd);
    return NO_ERROR;
}

static my_err_t handle_connection(int client_fd)
{
    char client_buf[10000] = {'\0'};
    int recv_len = 0;
    my_err_t err;

    // receive client http request header
    err = recv_hdr_from(client_fd, client_buf, sizeof(client_buf), &recv_len, NULL);
    if (err != NO_ERROR)
        return err;

    // parse http request header
    request_t request_hdr;
    init_request(&request_hdr);

    err = parse_request_header(client_buf, &request_hdr);
    if (err != NO_ERROR)
    {
        clear_request(&request_hdr);
        return err;
    }
    else if (strcasecmp(request_hdr.method, "GET"))
    {
        clear_request(&request_hdr);
        return UNSUPPORTED_METHOD;
    }
    else
    {
        err = print_http_debug(&request_hdr);
        if (err != NO_ERROR)
        {
            clear_request(&request_hdr);
            return err;
        }

        // forward client request to target server and send back the response
        err = forward(client_fd, &request_hdr);
        if (err != NO_ERROR)
        {
            clear_request(&request_hdr);
            return err;
        }

        clear_request(&request_hdr);
    }

    return NO_ERROR;
}