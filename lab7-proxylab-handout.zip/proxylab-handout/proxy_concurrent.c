// A Sequential HTTP proxy

#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#include "cache.h"
#include "csapp.h"
#include "error.h"
#include "error_response.h"
#include "parse.h"
#include "request.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
// #define MAX_CACHE_SIZE (MAX_OBJECT_SIZE * 1)

/* You won't lose style points for including this long line in your code */
static const char *USER_AGENT_HEADER = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

static const char *DEFAULT_PROXY_LISTEN_PORT = "12345";

static my_err_t accept_dbg(int listen_fd, int *client_fd);
static int min(int a, int b) { return (a < b) ? a : b; }
static int max(int a, int b) { return (a > b) ? a : b; }
static my_err_t handle_connection(int client_fd);
static my_err_t recv_hdr_from(int fd, char *buf, int buf_size, int *read_len, rio_t *rio_buf_p);
static my_err_t forward(int client_fd, const request_t *req);
static my_err_t print_http_debug(struct HttpHeader *hdr);
static void *start_serv(void *arg);

#define FD_BUF_SIZE (100)
static int client_fds[FD_BUF_SIZE];
static int rear, tail;
static sem_t client_fds_mutex;
static sem_t avaliable_fd_sem;
static sem_t remain_fd_sem;

static int get_fd_from_buf()
{
    int res;
    sem_wait(&avaliable_fd_sem);
    sem_wait(&client_fds_mutex);

    res = client_fds[tail];
    tail = (tail + 1) % FD_BUF_SIZE;
    my_error("[%4lu]GET_FD(%d),[TAIL,REAR]=[%d,%d]\n", pthread_self(), res, tail, rear);

    sem_post(&client_fds_mutex);

    return res;
}

static void put_fd_to_buf(int fd)
{
    sem_wait(&remain_fd_sem);
    sem_wait(&client_fds_mutex);

    client_fds[rear] = fd;
    rear = (rear + 1) % FD_BUF_SIZE;
    my_error("[%4lu]PUT_FD(%d),[TAIL,REAR]=[%d,%d]\n", pthread_self(), fd, tail, rear);

    sem_post(&avaliable_fd_sem);
    sem_post(&client_fds_mutex);
}

int main(const int argc, const char *argv[])
{
    char *fd = DEFAULT_PROXY_LISTEN_PORT;
    if (argc == 2)
        fd = (char *)argv[1];
    int listen_fd = Open_listenfd(fd);
    pthread_t tid = pthread_self();
    sem_init(&client_fds_mutex, 0, 1);
    sem_init(&avaliable_fd_sem, 0, 0);
    sem_init(&remain_fd_sem, 0, FD_BUF_SIZE);
    init_cache(MAX_CACHE_SIZE, MAX_OBJECT_SIZE);

    pthread_t workers[64];
    for (int i = 0; i < sizeof(workers) / sizeof(pthread_t); i++)
        pthread_create(&workers[i], NULL, &start_serv, NULL);

    while (1)
    {
        my_info("[%4lu]listening...\n", tid);

        int client_fd;
        my_err_t err = accept_dbg(listen_fd, &client_fd);
        if (err != NO_ERROR)
        {
            if (err == GETNAMEINFO_ERROR)
            {
                int res = rio_writen(client_fd, (void *)response_404(), strlen(response_404()));
                if (res < 0)
                    my_error("[%4lu]errno(%d): %s\n", tid, errno, strerror(errno));
            }
            else
            {
                int res = rio_writen(client_fd, (void *)response_500(), strlen(response_500()));
                if (res < 0)
                    my_error("[%4lu]errno(%d): %s\n", tid, errno, strerror(errno));
            }
        }
        else
        {
            put_fd_to_buf(client_fd);
        }

        // pthread_t child;
        // pthread_create(&child, NULL, &start_serv, (void *)client_fd);
    }

    // printf("%s", USER_AGENT_HEADER);
    return 0;
}

static void *start_serv(void *arg)
{
    pthread_detach(pthread_self());
    pthread_t tid = pthread_self();

    while (1)
    {
        int client_fd = get_fd_from_buf();

        my_err_t err = handle_connection(client_fd);
        const char *err_response = NULL;

        switch (err)
        {
        case NO_ERROR:
            break;

        case UNSUPPORTED_METHOD:
            my_error("[%4lu]%s", tid, my_error_msg(err));
            err_response = response_405();
            break;

        case BUFFER_SIZE_TOO_SMALL:
            my_error(my_error_msg(err));
            err_response = response_431();
            break;

        case GETNAMEINFO_ERROR:
            err_response = response_404();
            break;

        case UNKNOWN_ERROR:
            my_error("[%4lu]errno(%d): %s\n", tid, errno, strerror(errno));
            err_response = response_500();
            break;

        default:
            my_error("[%4lu]%s", tid, my_error_msg(err));
            err_response = response_500();
            break;
        }

        if (err_response)
        {
            int res = rio_writen(client_fd, (void *)err_response, strlen(err_response));
            if (res < 0)
                my_error("[%4lu]errno(%d): %s\n", tid, errno, strerror(errno));
        }

        Close(client_fd);
        my_info("[%4lu]connection closed, client_fd=%d\n", tid, client_fd);

        sem_post(&remain_fd_sem);
        my_error("[%4lu]CLOSE_FD(%d)\n", tid, client_fd);
    }
    return NULL;
}

static my_err_t accept_dbg(int listen_fd, int *client_fd)
{
    if (!client_fd)
        return INVALID_PARAM;

    struct sockaddr_storage info;
    socklen_t info_len = sizeof(info);

    memset(&info, 0, sizeof(info));

    *client_fd = Accept(listen_fd, (SA *)&info, &info_len);
    char host[256], serv[256];

    int res = getnameinfo((SA *)&info, sizeof(struct sockaddr_storage), host, sizeof(host), serv, sizeof(serv), 0);
    if (res != 0)
    {
        my_error("[%4lu]getnameinfo error: %s", pthread_self(), gai_strerror(res));
        return GETNAMEINFO_ERROR;
    }

    my_info("[%4lu]Get connection from host %s with port %s, client_fd = %d\n", pthread_self(), host, serv, *client_fd);

    return NO_ERROR;
}

static my_err_t recv_hdr_from(int fd, char *buf, int buf_size, int *read_len, rio_t *rio_buf_p)
{
    if (buf_size <= 0 || buf[0] != '\0')
        return INVALID_PARAM;

    int byte = 0, read_res = 0;
    char recv_buf[1000];

    rio_t rio_buf;
    if (!rio_buf_p)
    {
        Rio_readinitb(&rio_buf, fd);
        rio_buf_p = &rio_buf;
    }

    while ((read_res = rio_readlineb(rio_buf_p, recv_buf, min(sizeof(recv_buf), buf_size))) > 0)
    {
        byte += read_res;
        if (byte >= buf_size)
            return BUFFER_SIZE_TOO_SMALL;

        my_info("[%4lu]%s", pthread_self(), recv_buf);
        strcat(buf, recv_buf);
        if (strnlen(recv_buf, sizeof(recv_buf)) == 2 && recv_buf[0] == '\r' && recv_buf[1] == '\n')
            break;
    }

    if (read_res == -1)
        return UNKNOWN_ERROR;

    if (read_len)
        *read_len = byte;
    return NO_ERROR;
}

static my_err_t print_http_debug(struct HttpHeader *hdr)
{
    char req_dbg[2000] = {'\0'};

    my_err_t err = request_debug_str(req_dbg, sizeof(req_dbg), hdr);
    if (err != NO_ERROR)
        return err;

    my_info("[%4lu]%s\n", pthread_self(), req_dbg);
    return NO_ERROR;
}

static my_err_t forward(int client_fd, const request_t *req)
{
    char cache_content[MAX_OBJECT_SIZE + 1];
    cache_content[0] = '\0';
    my_err_t err;
    {
        int content_len;
        err = get_item(req->host, req->port_number, req->query, req->path, cache_content, sizeof(cache_content), &content_len);
        if (err == NO_ERROR)
        {
            int byte = 0;
            char *start = cache_content;
            while ((byte = rio_writen(client_fd, start, content_len)) > 0)
            {
                content_len -= byte;
                start += byte;
            }

            if (byte < 0)
                return UNKNOWN_ERROR;
            return NO_ERROR;
        }
        else if (err != CACHE_ITEM_NOT_FOUND)
        {
            return err;
        }
    }

    // my_error("[%4lu]CACHE:MISS(%s:%s:%s:%s)\n",
    //          pthread_self(),
    //          req->host ? req->host : "NIL",
    //          req->port_number ? req->port_number : "NIL",
    //          req->path ? req->path : "NIL",
    //          req->query ? req->query : "NIL");

    char forward_content[1000] = {'\0'};
    char buf[1000] = {'\0'};

    sprintf(buf, "%s %s%s HTTP/1.0\r\n", req->method, req->path, req->query ? req->query : "");
    strcat(forward_content, buf);

    for (int i = 0; i < req->header_size; i++)
    {
        if (!strcasecmp(req->headers[i].key, "Proxy-Connection") ||
            !strcasecmp(req->headers[i].key, "Cache-Control") ||
            !strcasecmp(req->headers[i].key, "Connection"))
            continue;
        sprintf(buf, "%s: %s\r\n", req->headers[i].key, req->headers[i].val);
        strcat(forward_content, buf);
    }

    sprintf(buf, "\r\n");
    strcat(forward_content, buf);

    int forward_fd = open_clientfd(req->host, req->port_number ? req->port_number : (char *)"80");
    if (forward_fd < 0)
        return OPENFD_FAIL;

    my_info("[%4lu]Open connection %s:%s\n", pthread_self(), req->host, req->port_number ? req->port_number : "80");

    int res = rio_writen(forward_fd, forward_content, strlen(forward_content));
    if (res == -1)
    {
        int errno_save = errno;
        Close(forward_fd);
        errno = errno_save;
        return UNKNOWN_ERROR;
    }

    buf[0] = '\0';
    rio_t forward_rio;
    rio_readinitb(&forward_rio, forward_fd);
    err = recv_hdr_from(forward_fd, buf, sizeof(buf), NULL, &forward_rio);
    if (err != NO_ERROR)
    {
        int errno_save = errno;
        Close(forward_fd);
        errno = errno_save;
        return err;
    }

    response_t response_hdr;
    init_response(&response_hdr);

    err = parse_response_header(buf, &response_hdr);
    if (err != NO_ERROR)
    {
        int errno_save = errno;
        clear_response(&response_hdr);
        Close(forward_fd);
        errno = errno_save;
        return 0;
    }

    print_http_debug(&response_hdr);
    res = rio_writen(client_fd, buf, strlen(buf));
    if (res < 0)
    {
        int errno_save = errno;
        Close(forward_fd);
        clear_response(&response_hdr);
        errno = errno_save;
        return UNKNOWN_ERROR;
    }

    if (!get_header(&response_hdr, "content-length"))
    {
        clear_response(&response_hdr);
        while ((res = rio_readnb(&forward_rio, buf, sizeof(buf))) > 0)
        {
            res = rio_writen(client_fd, buf, res);
            if (res < 0)
            {
                int errno_save = errno;
                Close(forward_fd);
                errno = errno_save;
                return UNKNOWN_ERROR;
            }
        }

        if (res < 0)
        {
            int errno_save = errno;
            Close(forward_fd);
            errno = errno_save;
            return UNKNOWN_ERROR;
        }
    }
    else
    {
        const char *val = get_header(&response_hdr, "content-length");
        int len = atoi(val);
        int header_len = strlen(buf);

        int can_proxy = (response_hdr.status_code[0] == '2' || response_hdr.status_code[0] == '3') && (len + header_len) < MAX_OBJECT_SIZE;
        char cache_store[MAX_OBJECT_SIZE];
        char *cur = cache_store;

        if (can_proxy)
        {
            memcpy(cur, buf, header_len);
            cur += header_len;
        }

        clear_response(&response_hdr);

        int byte = 0;

        while (len > 0 && (byte = rio_readnb(&forward_rio, buf, min(sizeof(buf), len))) > 0)
        {
            len -= byte;
            if (can_proxy)
            {
                memcpy(cur, buf, byte);
                cur += byte;
            }

            res = rio_writen(client_fd, buf, byte);
            if (res < 0)
            {
                int errno_save = errno;
                Close(forward_fd);
                errno = errno_save;
                return UNKNOWN_ERROR;
            }
        }

        if (byte < 0)
        {
            int errno_save = errno;
            Close(forward_fd);
            errno = errno_save;
            return UNKNOWN_ERROR;
        }

        if (can_proxy)
        {
            err = insert_item(req->host, req->port_number, req->query, req->path, cache_store, cur - cache_store);
            if (err != NO_ERROR)
            {
                Close(forward_fd);
                return err;
            }
            // my_error("[%4lu]CACHE:INSERT(%s:%s:%s:%s)\n",
            //          pthread_self(),
            //          req->host ? req->host : "NIL",
            //          req->port_number ? req->port_number : "NIL",
            //          req->path ? req->path : "NIL",
            //          req->query ? req->query : "NIL");
        }
    }
    Close(forward_fd);
    return NO_ERROR;
}

static my_err_t handle_connection(int client_fd)
{
    char client_buf[10000] = {'\0'};
    int recv_len = 0;
    my_err_t err;

    // receive client http request header
    err = recv_hdr_from(client_fd, client_buf, sizeof(client_buf), &recv_len, NULL);
    if (err != NO_ERROR)
        return err;

    // parse http request header
    request_t request_hdr;
    init_request(&request_hdr);

    err = parse_request_header(client_buf, &request_hdr);
    if (err != NO_ERROR)
    {
        clear_request(&request_hdr);
        return err;
    }
    else if (strcasecmp(request_hdr.method, "GET"))
    {
        clear_request(&request_hdr);
        return UNSUPPORTED_METHOD;
    }
    else
    {
        err = print_http_debug(&request_hdr);
        if (err != NO_ERROR)
        {
            clear_request(&request_hdr);
            return err;
        }

        // forward client request to target server and send back the response
        err = forward(client_fd, &request_hdr);
        if (err != NO_ERROR)
        {
            clear_request(&request_hdr);
            return err;
        }

        clear_request(&request_hdr);
    }

    return NO_ERROR;
}