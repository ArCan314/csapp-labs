#include "cache.h"

#include <assert.h>
#include <stdlib.h>
#include <string.h>

#include <pthread.h>
#include <semaphore.h>

#include "error.h"

typedef struct Key
{
    char *host;
    char *port;
    char *query;
    char *path;
} my_key_t;

typedef struct Link
{
    struct Link *pre;
    struct Link *next;
    unsigned hash_val;
    int read_cnt;
    sem_t cnt_mutex;
    my_key_t key;
    char *val;
    int val_len;
} link_t;

static link_t *head = NULL;
static link_t *tail = NULL;
static int cur_size = 0;
static int max_size = 0;
static int max_object_size = 0;
static pthread_rwlock_t mutex;
static int has_init = 0;

static int hash(const char *host, const char *port, const char *query, const char *path);
static void _init();
static void free_not_null(char *p);
static int is_key_equal(const my_key_t *key, const char *host, const char *port_number, const char *query, const char *path);
static my_err_t move_to_head(link_t *node);
static my_err_t eviction(void);
static my_err_t init_key(my_key_t *key, const char *host, const char *port_number, const char *query, const char *path);

int init_cache(int max_cache_size, int max_cache_object_size)
{
    static pthread_once_t once;
    pthread_once(&once, _init);

    pthread_rwlock_rdlock(&mutex);
    if (has_init)
    {
        pthread_rwlock_unlock(&mutex);
        return 1;
    }
    pthread_rwlock_unlock(&mutex);

    pthread_rwlock_wrlock(&mutex);
    cur_size = 0;
    max_size = max_cache_size;
    max_object_size = max_cache_object_size;

    head = NULL;
    tail = NULL;
    has_init = 1;
    pthread_rwlock_unlock(&mutex);

    return 1;
}

void destroy_cache()
{
    pthread_rwlock_rdlock(&mutex);
    if (!has_init)
    {
        pthread_rwlock_unlock(&mutex);
        return;
    }
    pthread_rwlock_unlock(&mutex);

    pthread_rwlock_wrlock(&mutex);
    link_t *cur = head;
    while (cur)
    {
        free_not_null(cur->key.host);
        free_not_null(cur->key.port);
        free_not_null(cur->key.query);
        free_not_null(cur->val);
        sem_destroy(&cur->cnt_mutex);
        cur = cur->next;
    }

    head = NULL;
    tail = NULL;
    cur_size = 0;
    max_size = 0;
    max_object_size = 0;
    has_init = 0;
    pthread_rwlock_unlock(&mutex);
}

my_err_t get_item(const char *host, const char *port, const char *query, const char *path, char *buf, const int buf_size, int *content_len)
{
    if (buf[0] != '\0' || content_len == NULL)
        return INVALID_PARAM;

    unsigned hash_val = hash(host, port, query, path);
    int update = 0;

    pthread_rwlock_rdlock(&mutex);

    // find item
    link_t *cur = head;
    while (cur)
    {
        if (cur->hash_val == hash_val && is_key_equal(&cur->key, host, port, query, path))
            break;
        cur = cur->next;
    }

    if (!cur)
    {
        pthread_rwlock_unlock(&mutex);
        return CACHE_ITEM_NOT_FOUND;
    }

    // determine update thread
    sem_wait(&cur->cnt_mutex);
    update = !cur->read_cnt;
    cur->read_cnt++;
    sem_post(&cur->cnt_mutex);

    if (buf_size < cur->val_len)
    {
        if (update)
        {
            sem_wait(&cur->cnt_mutex);
            cur->read_cnt = 0;
            sem_post(&cur->cnt_mutex);
        }
        pthread_rwlock_unlock(&mutex);
        return BUFFER_SIZE_TOO_SMALL;
    }

    // copy item value to buf
    memcpy(buf, cur->val, cur->val_len);
    *content_len = cur->val_len;

    my_error("[%4lu]CACHE:GET<%d/%d>(%s:%s:%s:%s)\n",
             pthread_self(),
             cur_size, max_size,
             cur->key.host ? cur->key.host : "NIL",
             cur->key.port ? cur->key.port : "NIL",
             cur->key.path ? cur->key.path : "NIL",
             cur->key.query ? cur->key.query : "NIL");

    pthread_rwlock_unlock(&mutex);

    // perform update
    if (update)
    {
        pthread_rwlock_wrlock(&mutex);

        my_err_t err = move_to_head(cur);
        if (err != NO_ERROR)
        {
            pthread_rwlock_unlock(&mutex);
            return err;
        }

        cur->read_cnt = 0; // needn't to call sem_wait
        pthread_rwlock_unlock(&mutex);
    }

    return NO_ERROR;
}

my_err_t insert_item(const char *host, const char *port, const char *query, const char *path, const char *val, int val_len)
{
    unsigned hash_val = hash(host, port, query, path);
    my_err_t err;

    pthread_rwlock_rdlock(&mutex);
    if (val_len > max_object_size)
    {
        pthread_rwlock_unlock(&mutex);
        return OBJECT_SIZE_TOO_LARGE;
    }

    pthread_rwlock_unlock(&mutex);

    pthread_rwlock_wrlock(&mutex);
    link_t *cur = head;
    while (cur)
    {
        if (cur->hash_val == hash_val && is_key_equal(&cur->key, host, port, query, path))
            break;
        cur = cur->next;
    }

    if (cur)
    {
        err = move_to_head(cur);
        if (err != NO_ERROR)
        {
            pthread_rwlock_unlock(&mutex);
            return err;
        }

        int origin_size = cur->val_len;
        while (cur_size - origin_size + val_len > max_size)
        {
            if ((err = eviction()) != NO_ERROR)
            {
                if (err == CACHE_IS_EMPTY)
                    break;
                else
                {
                    pthread_rwlock_unlock(&mutex);
                    return err;
                }
            }
        }

        free(cur->val);
        cur->val = (char *)malloc(val_len);
        memcpy(cur->val, val, val_len);
        cur_size = cur_size - origin_size + val_len;
    }
    else
    {
        while (cur_size + val_len > max_size)
            if ((err = eviction()) != NO_ERROR)
            {
                if (err == CACHE_IS_EMPTY)
                    break;
                else
                {
                    pthread_rwlock_unlock(&mutex);
                    return err;
                }
            }

        link_t *new_node = (link_t *)malloc(sizeof(link_t));
        memset(new_node, 0, sizeof(link_t));
        sem_init(&new_node->cnt_mutex, 0, 1);
        init_key(&new_node->key, host, port, query, path);
        new_node->hash_val = hash_val;
        new_node->val_len = val_len;

        new_node->val = (char *)malloc(val_len);
        memcpy(new_node->val, val, val_len);

        if (!head)
            head = tail = new_node;
        else
        {
            new_node->next = head;
            head->pre = new_node;
            head = new_node;
        }
        cur_size += val_len;
    }
    my_error("[%4lu]CACHE:INSERT<%d/%d>(%s:%s:%s:%s)\n",
             pthread_self(),
             cur_size, max_size,
             head->key.host ? head->key.host : "NIL",
             head->key.port ? head->key.port : "NIL",
             head->key.path ? head->key.path : "NIL",
             head->key.query ? head->key.query : "NIL");
    pthread_rwlock_unlock(&mutex);
    return NO_ERROR;
}

static int hash(const char *host, const char *port, const char *query, const char *path)
{
    long res = 0;
    int cur_pos = 0;
    const char *prepare[] = {host, "ANOTHER_SALT", port, query, "ONE_SALT", path};
    const int ROUND = 8;
    const int size = sizeof(prepare) / sizeof(char *);

    for (int i = 0; i < ROUND; i++)
    {
        int k = 0;
        int start = i % size;
        while (k++ < size)
        {
            const char *cur = prepare[start];
            start = (start + 1) % size;

            if (!cur)
                continue;

            int len = strlen(cur);
            for (int j = 0; j < len; j++)
            {
                res ^= (((int)cur[j]) << (cur_pos));
                cur_pos = (cur_pos + 17) % 32;
            }
        }
    }

    return res;
}

static void _init()
{
    pthread_rwlock_init(&mutex, NULL);
}

static void free_not_null(char *p)
{
    if (p)
        free(p);
}

static int is_key_equal(const my_key_t *key, const char *host, const char *port, const char *query, const char *path)
{
    int host_res, port_res, query_res, path_res;

    host_res = host ? !strcmp(key->host, host) : 1;
    port_res = port ? !strcmp(key->port, port) : 1;
    query_res = query ? !strcmp(key->query, query) : 1;
    path_res = path ? !strcmp(key->path, path) : 1;

    return host_res && port_res && query_res && path_res;
}

static my_err_t move_to_head(link_t *node)
{
    int err = pthread_rwlock_tryrdlock(&mutex);
    if (err == 0)
    {
        pthread_rwlock_unlock(&mutex);
        return NO_WRITE_MUTEX_PRIVILEGE;
    }

    link_t *pre = node->pre;
    link_t *next = node->next;

    if (node == head)
        return NO_ERROR;

    pre->next = next;
    if (node == tail)
        tail = pre;
    else
        next->pre = pre;

    node->next = head;
    node->pre = NULL;
    head->pre = node;
    head = node;

    return NO_ERROR;
}

static my_err_t eviction(void)
{
    int err = pthread_rwlock_tryrdlock(&mutex);
    if (err == 0)
    {
        pthread_rwlock_unlock(&mutex);
        return NO_WRITE_MUTEX_PRIVILEGE;
    }
    if (!head) // no item
        return CACHE_IS_EMPTY;

    link_t *cur = tail, *pre = tail->pre;
    if (!pre)
        tail = head = NULL;
    else
    {
        pre->next = NULL;
        tail = pre;
    }

    my_error("[%4lu]CACHE:EVICTION<%d/%d>(%s:%s:%s:%s)\n",
             pthread_self(),
             cur_size, max_size,
             cur->key.host ? cur->key.host : "NIL",
             cur->key.port ? cur->key.port : "NIL",
             cur->key.path ? cur->key.path : "NIL",
             cur->key.query ? cur->key.query : "NIL");
    cur_size -= cur->val_len;
    free_not_null(cur->key.host);
    free_not_null(cur->key.port);
    free_not_null(cur->key.query);
    free_not_null(cur->val);
    sem_destroy(&cur->cnt_mutex);

    return NO_ERROR;
}

static my_err_t init_key(my_key_t *key, const char *host, const char *port, const char *query, const char *path)
{
    if (host)
    {
        int host_len = strlen(host) + 1;
        key->host = (char *)malloc(host_len);
        memcpy(key->host, host, host_len);
    }

    if (port)
    {
        int port_len = strlen(port) + 1;
        key->port = (char *)malloc(port_len);
        memcpy(key->port, port, port_len);
    }

    if (query)
    {
        int query_len = strlen(query) + 1;
        key->query = (char *)malloc(query_len);
        memcpy(key->query, query, query_len);
    }

    if (path)
    {
        int path_len = strlen(path) + 1;
        key->path = (char *)malloc(path_len);
        memcpy(key->path, path, path_len);
    }

    return NO_ERROR;
}