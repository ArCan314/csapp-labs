#pragma once

#ifndef ERROR_PROC_HEADER
#define ERROR_PROC_HEADER

typedef enum MyError
{
    NO_ERROR,
    REQUEST_NOT_INITED,
    RESPONSE_NOT_INITED,
    UNSUPPORTED_METHOD,
    UNSUPPORTED_VERSION,
    HOST_MISSING,
    INCOMPLETE_REQUEST,
    INCOMPLETE_RESPONSE,
    INVALID_PROTOCOL,
    INVALID_HOST,
    INVALID_PORT_NUMBER,
    PARSE_URL_FAIL,
    TOO_MANY_HEADERS,
    BODY_NOT_SUPPORTED,
    BUFFER_SIZE_TOO_SMALL,
    MALLOC_FAIL,
    PARSE_STATUS_CODE_FAIL,
    INVALID_PARAM,
    UNKNOWN_ERROR,
    GETNAMEINFO_ERROR,
    OPENFD_FAIL,
    CACHE_ITEM_NOT_FOUND,
    NO_WRITE_MUTEX_PRIVILEGE,
    OBJECT_SIZE_TOO_LARGE,
    CACHE_IS_EMPTY,
    MY_ERR_SIZE_IDENTITY,
} my_err_t;

#ifndef my_info
#define my_info __ig__no__re_er__ror
#endif

const char *my_error_msg(my_err_t err_code);
void my_error(const char *msg, ...);
void __ig__no__re_er__ror(const char *msg, ...);

#endif // ERROR_PROC_HEADER