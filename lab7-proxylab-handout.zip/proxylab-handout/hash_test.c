#include <string.h>

#define HASH_SIZE (107)

int hash(const char *host, const char *port_number, const char *query)
{
    unsigned res = 0;
    int cur_pos = 0;
    const char *prepare[] = {host, "ANOTHER_SALT", port_number, query, "ONE_SALT"};
    const int ROUND = 16;
    const int size = sizeof(prepare) / sizeof(char *);

    for (int i = 0; i < ROUND; i++)
    {
        int k = 0;
        int start = i % size;
        while (k++ < size)
        {
            const char *cur = prepare[start];
            start = (start + 1) % size;

            if (!cur)
                continue;

            int len = strlen(cur);
            for (int j = 0; j < len; j++)
            {
                res ^= (((int)cur[j]) << (cur_pos));
                cur_pos = (cur_pos + 17) % 32;
            }
        }
    }

    return res % HASH_SIZE;
}