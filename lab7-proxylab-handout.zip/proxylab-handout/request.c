#include "request.h"
#include "error.h"

#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

const int HEADER_MAX_SIZE = 100;
const int BUF_MAXSIZE = 255 + 1;

static int sprintcmp(char *buf, int buf_len, int *cur_len, const char *format, ...);
static void free_not_null(char *member);
static const char *get_version_str(const version_t version);
static void init_fill_zeor(void *target, int size);
static void clear_all_member(struct HttpHeader *header);

void init_request(request_t *request)
{
    init_fill_zeor(request, sizeof(request_t));
}

void init_response(response_t *response)
{
    init_fill_zeor(response, sizeof(response_t));
}

// get_header case insensitive
const char *get_header(request_t *request, const char *key)
{
    for (int i = 0; i < request->header_size; i++)
    {
        if (!strcasecmp(request->headers[i].key, key))
            return request->headers[i].val;
    }
    return NULL;
}

void clear_request(request_t *request)
{
    clear_all_member(request);
}

void clear_response(response_t *response)
{
    clear_all_member(response);
}

int set_header(request_t *request, const char *key, const char *val, int val_len)
{
    for (int i = 0; i < request->header_size; i++)
        if (!strcasecmp(request->headers[i].key, key))
        {
            request->headers[i].val = (char *)realloc(request->headers[i].val, val_len + 1);
            memcpy(request->headers[i].val, val, val_len);
            request->headers[i].val[val_len] = '\0';
            return 1;
        }
    return 0;
}

void remove_header(request_t *request, const char *key)
{
    for (int i = 0; i < request->header_size; i++)
        if (!strcasecmp(request->headers[i].key, key))
        {
            free_not_null(request->headers[i].key);
            free_not_null(request->headers[i].val);
            memset(&request->headers[i], 0, sizeof(header_t));
            request->header_size--;

            memcpy(&request->headers[i], &request->headers[request->header_size], sizeof(header_t));
            memset(&request->headers[request->header_size], 0, sizeof(header_t));
            // return 1;
        }
    // return 0;
}

my_err_t append_header(request_t *request, const char *key, int key_len, const char *val, int val_len)
{
    int cur = request->header_size;
    if (request->header_size == HEADER_MAX_SIZE)
        return -1;

    request->headers[cur].key = (char *)malloc(key_len + 1);
    if (!request->headers[cur].key)
        return MALLOC_FAIL;

    request->headers[cur].key[key_len] = '\0';
    memcpy(request->headers[cur].key, key, key_len);

    request->headers[cur].val = (char *)malloc(val_len + 1);
    if (!request->headers[cur].val)
        return MALLOC_FAIL;

    request->headers[cur].val[val_len] = '\0';
    memcpy(request->headers[cur].val, val, val_len);

    request->header_size++;
    return 0;
}

my_err_t request_debug_str(char *buf, int buf_len, const request_t *request)
{
    int byte_count = 0;
    char in_buf[1000];
    memset(in_buf, 0, sizeof(in_buf));

    if (sprintcmp(buf, buf_len, &byte_count, "Request Debug Infomation:\n"))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "host= %s\n", request->host ? request->host : "not set"))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "path= %s\n", request->path ? request->path : "not set"))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "query= %s\n", request->query ? request->query : "not set"))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    // if (sprintcmp(in_buf, buf_len, &byte_count, "body= %s\n", request->body ? request->body : "not set"))
    //     return BUFFER_SIZE_TOO_SMALL;
    // strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "status_code= %s\n", request->status_code ? request->status_code : "not set"))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "status_info= %s\n", request->status_info ? request->status_info : "not set"))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "port_number= %s\n", request->port_number ? request->port_number : "not set"))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "method= %s\n", request->method))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "version= %s\n", get_version_str(request->version)))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    if (sprintcmp(in_buf, buf_len, &byte_count, "headers(%d):\n", request->header_size))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);

    for (int i = 0; i < request->header_size; i++)
    {
        const char *key = request->headers[i].key;
        const char *val = request->headers[i].val;

        if (sprintcmp(in_buf, buf_len, &byte_count, "\t(%d)%s: %s\n", i, key ? key : "NOTSET", val ? val : "NOTSET"))
            return BUFFER_SIZE_TOO_SMALL;
        strcat(buf, in_buf);
    }

    if (sprintcmp(in_buf, buf_len, &byte_count, "###Request Debug Infomation End###"))
        return BUFFER_SIZE_TOO_SMALL;
    strcat(buf, in_buf);
    return NO_ERROR;
}

static int sprintcmp(char *buf, int buf_len, int *cur_len, const char *format, ...)
{
    va_list args;
    va_start(args, format);

    vsprintf(buf, format, args);
    va_end(args);

    *cur_len += strlen(buf);

    if (*cur_len >= buf_len)
        return -1;
    return 0;
}

static void free_not_null(char *member)
{
    if (member)
        free(member);
}

static const char *get_version_str(const version_t version)
{
    assert(version > VER_SION_BEGIN && version < VER_SION_END);
    switch (version)
    {
    case V10:
        return "HTTP/1.0";
        break;
    case V11:
        return "HTTP/1.1";
        break;
    case V20:
        return "HTTP/2.0";
        break;
    default:
        assert(0);
        break;
    }
    return NULL;
}

static void init_fill_zeor(void *target, int size)
{
    memset(target, 0, size);
}

static void clear_all_member(struct HttpHeader *header)
{
    free_not_null(header->host);
    free_not_null(header->path);
    free_not_null(header->body);
    free_not_null(header->status_code);
    free_not_null(header->status_info);
    free_not_null(header->port_number);
    free_not_null(header->query);
    for (int i = 0; i < HEADER_MAX_SIZE; i++)
    {
        free_not_null(header->headers[i].key);
        free_not_null(header->headers[i].val);
    }
    init_fill_zeor(header, sizeof(struct HttpHeader));
}