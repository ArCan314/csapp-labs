#pragma once

#ifndef CACHE_PROC_HEARDER
#define CACHE_PROC_HEARDER

enum MyError;
typedef enum MyError my_err_t;

int init_cache(int max_size, int max_object_size);
void destroy_cache();

my_err_t get_item(const char *host, const char *port, const char *query, const char *path, char *buf, const int buf_size, int *content_len);
my_err_t insert_item(const char *host, const char *port, const char *query, const char *path, const char *val, int val_len);

#endif // CACHE_PROC_HEARDER