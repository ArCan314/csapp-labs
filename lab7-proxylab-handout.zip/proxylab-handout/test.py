HASH_SIZE = 107

def hash(a, b, c):
    content = [a, b, 'a_salt', c, 'another_salt']
    round = 16
    size = len(content)
    res = 0
    pos = 0
    for i in range(round):
        k = 0
        start = i % size
        while k < size:
            cur = content[start]
            start = (start + 1) % size
            k += 1
            for char in cur:
                res ^= (ord(char) << pos)
                pos = (pos + 17) % 32
    return res % HASH_SIZE

from ctypes import *

dll = CDLL("./libhash_test.so")
hash_test = {}

for i in range(HASH_SIZE):
    hash_test[i] = 0

# I, J, K = 200, 200, 200
# prepare = [create_string_buffer(str(_).encode()) for _ in range(max(I, J, K))]
str_empty = create_string_buffer("".encode())

# for i in range(I):
#     print(i)
#     for j in range(J):
#         for k in range(K):
#             hash_test[dll.hash(prepare[i], prepare[j], prepare[k])] += 1
#             hash_test[dll.hash(prepare[i], str_empty, prepare[k])] += 1
#             hash_test[dll.hash(str_empty, str_empty, prepare[k])] += 1
#             hash_test[dll.hash(str_empty, prepare[j], prepare[k])] += 1
#         hash_test[dll.hash(prepare[i], prepare[j], str_empty)] += 1
#     hash_test[dll.hash(prepare[i], str_empty, str_empty)] += 1
# hash_test[dll.hash(str_empty, str_empty, str_empty)] += 1
import random
import string

def rand_string(size, chars=string.printable):
    return ''.join(random.choice(chars) for _ in range(size))

SIZE = 1000000
for i in range(SIZE):
    if i % 10000 == 0:
        print(i // 10000)
    a = create_string_buffer(rand_string(random.randint(0, 500)).encode())
    b = create_string_buffer(rand_string(random.randint(0, 5), string.digits).encode())
    c = create_string_buffer(rand_string(random.randint(0, 1000)).encode())

    hash_test[dll.hash(a, b, c)] += 1
    hash_test[dll.hash(a, str_empty, c)] += 1
    hash_test[dll.hash(str_empty, str_empty, c)] += 1
    hash_test[dll.hash(str_empty, b, c)] += 1
    hash_test[dll.hash(a, b, str_empty)] += 1
    hash_test[dll.hash(a, str_empty, str_empty)] += 1
    hash_test[dll.hash(str_empty, b, str_empty)] += 1
hash_test[dll.hash(str_empty, str_empty, str_empty)] += 1

# total = 4 * (I*J*K) + (I*J) + I + 1
total = SIZE * 7 + 1
for k, v in hash_test.items():
    print(k, v, v / total)